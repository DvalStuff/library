import React, { useEffect, useState } from 'react';

const Librarian = () => {

    return (
        <div className='footer'>
            <p>Librarian</p>
        </div>
    );
};

export default Librarian;
