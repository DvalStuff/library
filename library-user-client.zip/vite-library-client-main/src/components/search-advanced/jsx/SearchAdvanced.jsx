import React, { useEffect, useState } from 'react';

const SearchAdvanced = () => {

    return (
        <div className='footer'>
            <p>SearchAdvanced</p>
        </div>
    );
};

export default SearchAdvanced;
