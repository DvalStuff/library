import React, { useEffect, useState } from 'react';

const Bibliographer = () => {

    return (
        <div className='footer'>
            <p>Bibliographer</p>
        </div>
    );
};

export default Bibliographer;
