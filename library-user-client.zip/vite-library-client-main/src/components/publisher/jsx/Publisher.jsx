import React, { useEffect, useState } from 'react';

const Publisher = () => {

    return (
        <div className='footer'>
            <p>Publisher</p>
        </div>
    );
};

export default Publisher;
