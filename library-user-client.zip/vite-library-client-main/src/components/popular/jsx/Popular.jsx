import React, { useEffect, useState } from 'react';

const Popular = () => {

    return (
        <div className='footer'>
            <p>Popular</p>
        </div>
    );
};

export default Popular;
