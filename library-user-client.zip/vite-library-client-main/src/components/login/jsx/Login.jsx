import React, { useEffect, useState } from 'react';

const Login = () => {

    return (
        <div className='footer'>
            <p>Login</p>
        </div>
    );
};

export default Login;
