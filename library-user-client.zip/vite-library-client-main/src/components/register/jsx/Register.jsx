import React, { useEffect, useState } from 'react';

const Register = () => {

    return (
        <div className='footer'>
            <p>Register</p>
        </div>
    );
};

export default Register;
