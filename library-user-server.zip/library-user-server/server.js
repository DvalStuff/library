const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const session = require('express-session');
const dotenv = require('dotenv');
require('dotenv').config({ path: './config.env' });

const allBooksController = require('./controllers/allBooksController');
const signupController = require('./controllers/signupController.js');
const signinController = require('./controllers/signinController.js');
const searchController = require('./controllers/searchController.js');
const bookController = require('./controllers/bookController.js');
const lendBookController = require('./controllers/lendBookController.js');
const publisherController = require('./controllers/publisherController.js');

const app = express();

const pool = require("./db");
const sessionSecret = process.env.SESSION_SECRET || 'my-secret-key';

app.use(bodyParser.json());
app.use(cors({
    origin: 'http://localhost:3000', // Replace with your frontend's URL
    credentials: true,
}));

app.use(session({
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
}));

dotenv.config();

// POST 
app.post("/signup", signupController.signup);
app.post("/signin", signinController.signin);

app.post("/lend-book", (req, res, next) => {
    req.pool = pool;
    next();
}, lendBookController.lendBook);

// GET
app.get('/all', (req, res, next) => {
    req.pool = pool;
    next();
}, allBooksController.allBooks);

app.get('/search', (req, res, next) => {
    req.pool = pool;
    next();
}, searchController.searchBooks);

app.get('/book/:bookId', (req, res, next) => {
    req.pool = pool;
    next();
}, bookController.book);

// В server.js добавьте следующий маршрут:
app.get('/publisher', (req, res, next) => {
    req.pool = pool;
    next();
}, publisherController.getAllPublishers);


app.get('/publisher/:publisherId/books', (req, res, next) => {
    req.pool = pool;
    next();
}, publisherController.getBooksByPublisher);


app.get('/myBooks', (req, res, next) => {
    req.pool = pool;
    next();
}, async (req, res) => {
    const readerName = req.query.readerName;
    try {
        const query = 'SELECT * FROM library.book_formulary WHERE reader_full_name = $1';
        const books = await req.pool.query(query, [readerName]);
        res.json(books.rows);
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
        console.error(err);
    }
});


pool.on('error', (err, client) => {
    console.error('Unexpected error on idle client', err);
    process.exit(-1);
});

pool.connect((err, client, done) => {
    if (err) {
        console.log('PostgreSQL connection failed: ', err);
    } else {
        console.log('PostgreSQL connection successful');
        done();
    }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
