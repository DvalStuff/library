// publisherController.js
const getPublishers = async (req, res) => {
    try {
        const { pool } = req;
        const result = await pool.query('SELECT * FROM library.publisher ORDER BY publisher_id ASC');
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching publishers:', error);
        res.status(500).send('Server error');
    }
};

const getBooksByPublisher = async (req, res) => {
    const publisherId = req.params.publisherId; // получаем ID издателя из параметра маршрута
    try {
        const { pool } = req;
        const result = await pool.query('SELECT * FROM library.book WHERE publisher_id = $1', [publisherId]);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching books:', error);
        res.status(500).send('Server error');
    }
};



module.exports = {
    getAllPublishers: getPublishers,
    getBooksByPublisher: getBooksByPublisher,
};
